CFG_PATH="/data/adb/naki/asopt.conf"
MODS_PATH="/data/adb/modules"

mkdir -p /data/adb/naki $MODS_PATH
mode=`grep mode= $CFG_PATH`
rt=`grep rt= $CFG_PATH`

[ -z $mode ] && mode=`grep mode= /sdcard/Android/naki/asopt/asopt.conf`
[ -z $mode ] && mode="mode=0"
[ -z $rt ] && rt="rt=0"

echo "
- 配置文件位于 $CFG_PATH
- The config file is at $CFG_PATH
"
echo "# mode：运行模式 / Operation Mode
# 0：硬亲和，理论上表现更好 / Affinity, performs better in theory
# 1：软迁移，帧率可能更稳定 / Soft migrate, fps maybe more stable
# 2：硬迁移，帧率可能更稳定 / Hard migrate, fps maybe more stable

# rt：实时模式 / Real-Time Mode
# 0：调度器默认行为 / Scheduler default behavior
# 1：帧率可能更稳定，但可能导致卡死 / fps maybe more stable, but may cause freeze

# ***重启生效 / Reboot to take effect***

$mode
$rt" > $CFG_PATH

chmod +x $MODPATH/AsoulOpt
rm -rf $MODPATH/customize.sh /sdcard/Android/naki/asopt

killall -15 AsoulOpt
cp -af $MODPATH $MODS_PATH
sh $MODS_PATH/asoul_affinity_opt/service.sh
