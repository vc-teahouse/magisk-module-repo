## Highlights
- Support for Mi Drive
- Support for Mi Video (Global)
- Support for Mi Wallpaper Carousel (CN)
- Support for Mi Wallpaper Carousel (Global)

## Other changes
- Dropped support for calculator version < 15
- Weird background in third-party apps fixed
- Design improvements, updates & more fixes

---

Made with ❤️