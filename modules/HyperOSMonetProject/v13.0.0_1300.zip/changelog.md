# v13.0.0 - May 01, 2023

## Highlights
- Support for Scanner
- Support for Feedback
- Support for Floating windows
- Support for Services & feedback
- Support for Global Permission controller

## Other changes
- Added compatibility with HyperOS system apps
- Dropped support for Global File Manager (Old UI)
- Design improvements, updates & fixes

---

Made with ❤️